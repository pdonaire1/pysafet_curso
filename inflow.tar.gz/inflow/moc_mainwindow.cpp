/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Wed Jul 16 16:14:00 2014
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      80,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      16,   12,   11,   11, 0x0a,
      29,   12,   11,   11, 0x0a,
      47,   42,   11,   11, 0x0a,
      60,   11,   11,   11, 0x2a,
      69,   11,   11,   11, 0x0a,
      87,   11,   11,   11, 0x0a,
     111,  109,   11,   11, 0x0a,
     140,   11,   11,   11, 0x08,
     157,   11,   11,   11, 0x08,
     165,   11,   11,   11, 0x08,
     190,  177,   11,   11, 0x08,
     223,  216,   11,   11, 0x28,
     244,   11,   11,   11, 0x28,
     258,  216,   11,   11, 0x08,
     282,   11,   11,   11, 0x28,
     299,  216,   11,   11, 0x08,
     320,   11,   11,   11, 0x28,
     334,   11,   11,   11, 0x08,
     353,   11,   11,   11, 0x08,
     368,   11,   11,   11, 0x08,
     387,   11,   11,   11, 0x08,
     406,   11,   11,   11, 0x08,
     422,   11,   11,   11, 0x08,
     438,   11,   11,   11, 0x08,
     457,   11,   11,   11, 0x08,
     479,  475,   11,   11, 0x08,
     501,   11,   11,   11, 0x08,
     518,   11,   11,   11, 0x08,
     527,   11,   11,   11, 0x08,
     545,  537,   11,   11, 0x08,
     572,   11,   11,   11, 0x08,
     589,   11,   11,   11, 0x08,
     608,   11,   11,   11, 0x08,
     627,   11,   11,   11, 0x08,
     644,   11,   11,   11, 0x08,
     664,   11,   11,   11, 0x08,
     684,   11,   11,   11, 0x08,
     706,   11,   11,   11, 0x08,
     741,   11,   11,   11, 0x08,
     761,   11,   11,   11, 0x08,
     782,   11,   11,   11, 0x08,
     801,   11,   11,   11, 0x08,
     820,   11,   11,   11, 0x08,
     840,   11,   11,   11, 0x08,
     859,   11,   11,   11, 0x08,
     879,   11,   11,   11, 0x08,
     897,   11,   11,   11, 0x08,
     937,   11,   11,   11, 0x08,
     955,  953,   11,   11, 0x08,
     999,   11,   11,   11, 0x28,
    1021,  953,   11,   11, 0x08,
    1066,   11,   11,   11, 0x28,
    1091, 1089,   11,   11, 0x08,
    1131, 1122,   11,   11, 0x08,
    1153,   11,   11,   11, 0x08,
    1171,   11,   11,   11, 0x08,
    1186,   11,   11,   11, 0x08,
    1200,   11,   11,   11, 0x08,
    1217,   11,   11,   11, 0x08,
    1235,   11,   11,   11, 0x08,
    1257,   11,   11,   11, 0x08,
    1284, 1279,   11,   11, 0x08,
    1324,   11, 1316,   11, 0x08,
    1352, 1349,   11,   11, 0x08,
    1389, 1385, 1316,   11, 0x08,
    1421,   11,   11,   11, 0x0a,
    1433,   11,   11,   11, 0x0a,
    1445,   12,   11,   11, 0x0a,
    1469,   12,   11,   11, 0x0a,
    1497, 1495,   11,   11, 0x0a,
    1521,   11,   11,   11, 0x2a,
    1541,   11,   11,   11, 0x0a,
    1555,   11, 1550,   11, 0x0a,
    1567,   11,   11,   11, 0x0a,
    1591,   11, 1581,   11, 0x0a,
    1609,   11,   11,   11, 0x0a,
    1624,   11,   11,   11, 0x0a,
    1650,   11,   11,   11, 0x0a,
    1679, 1670,   11,   11, 0x0a,
    1723, 1720,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0url\0browse(QUrl)\0mailTo(QUrl)\0"
    "sign\0toSend(bool)\0toSend()\0toDoGoPanelEdit()\0"
    "createInitialTables()\0,\0"
    "ftpCommandFinished(int,bool)\0"
    "timeHideResult()\0about()\0toLoadWeb()\0"
    "action,isgui\0toInputForm(QString,bool)\0"
    "action\0toInputForm(QString)\0toInputForm()\0"
    "toInputConsole(QString)\0toInputConsole()\0"
    "toInputSign(QString)\0toInputSign()\0"
    "toInputConfigure()\0toInputUsers()\0"
    "toDelAllWorkflow()\0toDelOneWorkflow()\0"
    "toAddNodeflow()\0toDelNodeflow()\0"
    "toReloadNodeflow()\0toClearTextEdit()\0"
    "opt\0checkSelInputTab(int)\0selInputTab(int)\0"
    "doQuit()\0doPrint()\0printer\0"
    "doPrintDocument(QPrinter*)\0doPrintPreview()\0"
    "doGeneralOptions()\0doWidgetsOptions()\0"
    "setToInputForm()\0setToInputConsole()\0"
    "setToInputReports()\0setToInputFlowGraph()\0"
    "setToInputManagementSignDocument()\0"
    "doGetSignDocument()\0doSendSignDocument()\0"
    "checkGoPrincipal()\0addToHistoryList()\0"
    "editToHistoryList()\0delToHistoryList()\0"
    "saveToHistoryList()\0loadEditActions()\0"
    "insertFromHistoryList(QListWidgetItem*)\0"
    "showSmartMenu()\0a\0"
    "showSmartMenuWidget(DockSbMenu::ShowAction)\0"
    "showSmartMenuWidget()\0"
    "showShowResultWidget(DockSbMenu::ShowAction)\0"
    "showShowResultWidget()\0m\0"
    "showSuccessfulMessage(QString)\0filename\0"
    "drawWorkflow(QString)\0doAssistantHelp()\0"
    "toChangeUser()\0doSaveGraph()\0"
    "doRestoreGraph()\0doCompareGraphs()\0"
    "doLoadConfiguration()\0doSaveConfiguration()\0"
    "path\0setPathOfSafetDocument(QString)\0"
    "QString\0getPathOfSafetDocument()\0rx\0"
    "doInsertInAuthConfFile(QRegExp&)\0key\0"
    "searchFieldsInAuthConf(QString)\0"
    "doLoadFTP()\0doSaveFTP()\0linkClickedSbMenu(QUrl)\0"
    "linkClickedSbResult(QUrl)\0e\0"
    "setEnabledToolBar(bool)\0setEnabledToolBar()\0"
    "doExit()\0bool\0maybeSave()\0goPrincipal()\0"
    "TextEdit*\0currentTextEdit()\0threadEndJob()\0"
    "processMainWindowThread()\0manageDataSources()\0"
    "dbConfig\0manageDataSources(DatabaseConfigDialog*)\0"
    "ok\0executeJSCodeAfterLoad(bool)\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->browse((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 1: _t->mailTo((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 2: _t->toSend((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->toSend(); break;
        case 4: _t->toDoGoPanelEdit(); break;
        case 5: _t->createInitialTables(); break;
        case 6: _t->ftpCommandFinished((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 7: _t->timeHideResult(); break;
        case 8: _t->about(); break;
        case 9: _t->toLoadWeb(); break;
        case 10: _t->toInputForm((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 11: _t->toInputForm((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->toInputForm(); break;
        case 13: _t->toInputConsole((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->toInputConsole(); break;
        case 15: _t->toInputSign((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->toInputSign(); break;
        case 17: _t->toInputConfigure(); break;
        case 18: _t->toInputUsers(); break;
        case 19: _t->toDelAllWorkflow(); break;
        case 20: _t->toDelOneWorkflow(); break;
        case 21: _t->toAddNodeflow(); break;
        case 22: _t->toDelNodeflow(); break;
        case 23: _t->toReloadNodeflow(); break;
        case 24: _t->toClearTextEdit(); break;
        case 25: _t->checkSelInputTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->selInputTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->doQuit(); break;
        case 28: _t->doPrint(); break;
        case 29: _t->doPrintDocument((*reinterpret_cast< QPrinter*(*)>(_a[1]))); break;
        case 30: _t->doPrintPreview(); break;
        case 31: _t->doGeneralOptions(); break;
        case 32: _t->doWidgetsOptions(); break;
        case 33: _t->setToInputForm(); break;
        case 34: _t->setToInputConsole(); break;
        case 35: _t->setToInputReports(); break;
        case 36: _t->setToInputFlowGraph(); break;
        case 37: _t->setToInputManagementSignDocument(); break;
        case 38: _t->doGetSignDocument(); break;
        case 39: _t->doSendSignDocument(); break;
        case 40: _t->checkGoPrincipal(); break;
        case 41: _t->addToHistoryList(); break;
        case 42: _t->editToHistoryList(); break;
        case 43: _t->delToHistoryList(); break;
        case 44: _t->saveToHistoryList(); break;
        case 45: _t->loadEditActions(); break;
        case 46: _t->insertFromHistoryList((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 47: _t->showSmartMenu(); break;
        case 48: _t->showSmartMenuWidget((*reinterpret_cast< DockSbMenu::ShowAction(*)>(_a[1]))); break;
        case 49: _t->showSmartMenuWidget(); break;
        case 50: _t->showShowResultWidget((*reinterpret_cast< DockSbMenu::ShowAction(*)>(_a[1]))); break;
        case 51: _t->showShowResultWidget(); break;
        case 52: _t->showSuccessfulMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 53: _t->drawWorkflow((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 54: _t->doAssistantHelp(); break;
        case 55: _t->toChangeUser(); break;
        case 56: _t->doSaveGraph(); break;
        case 57: _t->doRestoreGraph(); break;
        case 58: _t->doCompareGraphs(); break;
        case 59: _t->doLoadConfiguration(); break;
        case 60: _t->doSaveConfiguration(); break;
        case 61: _t->setPathOfSafetDocument((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 62: { QString _r = _t->getPathOfSafetDocument();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 63: _t->doInsertInAuthConfFile((*reinterpret_cast< QRegExp(*)>(_a[1]))); break;
        case 64: { QString _r = _t->searchFieldsInAuthConf((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 65: _t->doLoadFTP(); break;
        case 66: _t->doSaveFTP(); break;
        case 67: _t->linkClickedSbMenu((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 68: _t->linkClickedSbResult((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 69: _t->setEnabledToolBar((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 70: _t->setEnabledToolBar(); break;
        case 71: _t->doExit(); break;
        case 72: { bool _r = _t->maybeSave();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 73: _t->goPrincipal(); break;
        case 74: { TextEdit* _r = _t->currentTextEdit();
            if (_a[0]) *reinterpret_cast< TextEdit**>(_a[0]) = _r; }  break;
        case 75: _t->threadEndJob(); break;
        case 76: _t->processMainWindowThread(); break;
        case 77: _t->manageDataSources(); break;
        case 78: _t->manageDataSources((*reinterpret_cast< DatabaseConfigDialog*(*)>(_a[1]))); break;
        case 79: _t->executeJSCodeAfterLoad((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 80)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 80;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

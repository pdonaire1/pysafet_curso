/****************************************************************************
** Meta object code from reading C++ file 'textedit.h'
**
** Created: Wed Jul 16 16:14:03 2014
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "textedit.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'textedit.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TextEdit[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   10,    9,    9, 0x08,
      52,   50,    9,    9, 0x28,
      85,   74,    9,    9, 0x08,
     117,  111,    9,    9, 0x0a,
     143,    9,    9,    9, 0x0a,
     161,    9,    9,    9, 0x0a,
     182,    9,    9,    9, 0x0a,
     197,    9,    9,    9, 0x0a,
     214,    9,    9,    9, 0x0a,
     241,  236,  231,    9, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_TextEdit[] = {
    "TextEdit\0\0r,caption\0showFromWidget(QRect,QString)\0"
    "r\0showFromWidget(QRect)\0completion\0"
    "insertCompletion(QString)\0title\0"
    "execSbMenuAction(QString)\0delCurrentField()\0"
    "modifyCurrentField()\0doTextChange()\0"
    "cancelAndClose()\0insertAndClose()\0"
    "bool\0list\0searchPrvsToken(QStringList&)\0"
};

void TextEdit::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TextEdit *_t = static_cast<TextEdit *>(_o);
        switch (_id) {
        case 0: _t->showFromWidget((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 1: _t->showFromWidget((*reinterpret_cast< const QRect(*)>(_a[1]))); break;
        case 2: _t->insertCompletion((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->execSbMenuAction((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->delCurrentField(); break;
        case 5: _t->modifyCurrentField(); break;
        case 6: _t->doTextChange(); break;
        case 7: _t->cancelAndClose(); break;
        case 8: _t->insertAndClose(); break;
        case 9: { bool _r = _t->searchPrvsToken((*reinterpret_cast< QStringList(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObjectExtraData TextEdit::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject TextEdit::staticMetaObject = {
    { &QTextEdit::staticMetaObject, qt_meta_stringdata_TextEdit,
      qt_meta_data_TextEdit, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TextEdit::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TextEdit::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TextEdit::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TextEdit))
        return static_cast<void*>(const_cast< TextEdit*>(this));
    return QTextEdit::qt_metacast(_clname);
}

int TextEdit::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTextEdit::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

/****************************************************************************
** Meta object code from reading C++ file 'infloweditqlistwidget.h'
**
** Created: Wed Jul 16 16:14:37 2014
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "infloweditqlistwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'infloweditqlistwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_InflowEditQListWidget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      23,   22,   22,   22, 0x08,
      33,   22,   22,   22, 0x08,
      43,   22,   22,   22, 0x08,
      54,   22,   22,   22, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_InflowEditQListWidget[] = {
    "InflowEditQListWidget\0\0delItem()\0"
    "addItem()\0editItem()\0areItemsEnabled()\0"
};

void InflowEditQListWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        InflowEditQListWidget *_t = static_cast<InflowEditQListWidget *>(_o);
        switch (_id) {
        case 0: _t->delItem(); break;
        case 1: _t->addItem(); break;
        case 2: _t->editItem(); break;
        case 3: _t->areItemsEnabled(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData InflowEditQListWidget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject InflowEditQListWidget::staticMetaObject = {
    { &CmdWidget::staticMetaObject, qt_meta_stringdata_InflowEditQListWidget,
      qt_meta_data_InflowEditQListWidget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &InflowEditQListWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *InflowEditQListWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *InflowEditQListWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_InflowEditQListWidget))
        return static_cast<void*>(const_cast< InflowEditQListWidget*>(this));
    return CmdWidget::qt_metacast(_clname);
}

int InflowEditQListWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CmdWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
static const uint qt_meta_data_Inflow__ListDialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      23,   20,   19,   19, 0x0a,
      57,   51,   19,   19, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Inflow__ListDialog[] = {
    "Inflow::ListDialog\0\0id\0"
    "predefineButtonClicked(int)\0state\0"
    "setEditInfoType(bool)\0"
};

void Inflow::ListDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ListDialog *_t = static_cast<ListDialog *>(_o);
        switch (_id) {
        case 0: _t->predefineButtonClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->setEditInfoType((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Inflow::ListDialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Inflow::ListDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Inflow__ListDialog,
      qt_meta_data_Inflow__ListDialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Inflow::ListDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Inflow::ListDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Inflow::ListDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Inflow__ListDialog))
        return static_cast<void*>(const_cast< ListDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int Inflow::ListDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

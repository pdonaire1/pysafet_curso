/*
* SAFET Sistema Automatizado para la Firma Electr�nica y Estampado de Tiempo
* Copyright (C) 2008 V�ctor Bravo (vbravo@cenditel.gob.ve), Antonio Araujo (aaraujo@cenditel.gob.ve
*
* CENDITEL Fundacion Centro Nacional de Desarrollo e Investigaci�n en Tecnologías Libres
*
* Este programa es software libre; Usted puede usarlo bajo los t�rminos de la licencia de
* software GPL versi�n 2.0 de la Free Software Foundation.
*
* Este programa se distribuye con la esperanza de que sea �til, pero SI NINGUNA GARANT�A;
* tampoco las impl��citas garant��as de MERCANTILIDAD o ADECUACIÓN A UN PROP�SITO PARTICULAR.
* Consulte la licencia GPL para m�s detalles. Usted debe recibir una copia de la GPL junto
* con este programa; si no, escriba a la Free Software Foundation Inc. 51 Franklin Street,
* 5� Piso, Boston, MA 02110-1301, USA.
*
*/
#include "numberwidget.h"
#include "SafetYAWL.h"

NumberWidget::NumberWidget(const QString& t, QWidget *parent, bool istextparent )
    :CmdWidget(t,parent, istextparent) {
     spinboxedit = NULL;


}

void NumberWidget::setText(const QString &newText) {

    bool ok;
    if (spinboxedit) {
        if (QString(spinboxedit->metaObject()->className()) == "QSpinBox" )  {

            QSpinBox *myspinbox = qobject_cast<QSpinBox*>(spinboxedit);
            Q_CHECK_PTR(myspinbox);
            myspinbox->setValue(newText.toInt(&ok));

        }
        else if (QString(spinboxedit->metaObject()->className()) == "QDoubleSpinBox" ) {
            QDoubleSpinBox *myspinbox = qobject_cast<QDoubleSpinBox*>(spinboxedit);
            Q_CHECK_PTR(myspinbox);
            myspinbox->setValue(newText.toDouble(&ok));

        }
    }

}


QRect NumberWidget::getGeoParams() const {
     QRect result;
     result.setHeight( 40 );
     result.setWidth( 150 );
     return result;
}

void NumberWidget::buildWidget() {
     qDebug("...NumberWidget...buildWidget...");

     spinboxedit = NULL;
     if ( conf().contains("options"))  {

         setOptionsProperties(conf()["options"].toString().split(","));
         if ( conf()["options"].toString().split(",").contains("decimal") ) {
             spinboxedit = new QDoubleSpinBox();
         }
         else {
            spinboxedit = new QSpinBox();
            (qobject_cast<QSpinBox*>(spinboxedit))->setRange(0,9999);
         }
     }
     else {
         spinboxedit = new QSpinBox();
         (qobject_cast<QSpinBox*>(spinboxedit))->setRange(0,9999);
     }

     principalWidget = spinboxedit;
     QString mytip = tr("Campo Num�rico. Escriba un n�mero entero o decimal");
     if ( conf().contains("validation")) {
         QStringList mylist = conf()["validation"].toString().split("::");
         if (mylist.count() > 1 ) {
             QString usertip = mylist.at(1);
             mytip = usertip;
         }
     }
     _usertooltip = mytip;
     spinboxedit->setToolTip(mytip);

     setOptionsProperties(conf()["options"].toString().split(",")); // Colocar las propiedades
     spinboxedit->setGeometry(0,0,350,30);



     if (isTextParent()) {
         okbutton = new QToolButton;
         okbutton->setGeometry(0,0,25,30);
         okbutton->setIcon(QIcon(":/yes.png"));
         quitbutton = new QToolButton;
         quitbutton->setGeometry(0,0,25,30);
         quitbutton->setText( "X");
     }
     mainLayout = new QHBoxLayout;
     mainLayout->addWidget(spinboxedit);
     //mainLayout->addWidget(lblvalidator);
     mainLayout->setSpacing( 1 );

     if ( isTextParent()) {
        mainLayout->addWidget(quitbutton);
        mainLayout->addWidget(okbutton);
        connect(okbutton, SIGNAL(clicked()), _texteditparent, SLOT(insertAndClose()) );
        connect(quitbutton, SIGNAL(clicked()), _texteditparent, SLOT(cancelAndClose()) );
    }
     setLayout(mainLayout);
}

void NumberWidget::setFocus ( Qt::FocusReason reason ) {
     qDebug("...NumberWidget::setFocus....(text)");
     QWidget::setFocus ( reason );
     spinboxedit->setFocus( reason);

}



QString NumberWidget::text() const {
    QString result;
    QString spclassname = "QSpinBox";
    QString sdpclassname = "QDoubleSpinBox";
    if (spinboxedit != NULL )  {
        if (spclassname.compare(spinboxedit->metaObject()->className()) == 0  ) {
                result = (qobject_cast<QSpinBox*>(spinboxedit))->cleanText();
                result.replace(".","");

            }
        else if (sdpclassname.compare(spinboxedit->metaObject()->className()) == 0  ) {
            result = (qobject_cast<QDoubleSpinBox*>(spinboxedit))->cleanText();
            result.replace(".","");
            result.replace(",",".");
        }
    }
       return result;
 }

/****************************************************************************
** Meta object code from reading C++ file 'texteditwidget.h'
**
** Created: Wed Jul 16 16:14:19 2014
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "texteditwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'texteditwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TextEditWidget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      24,   16,   15,   15, 0x0a,
      41,   15,   15,   15, 0x0a,
      51,   15,   15,   15, 0x0a,
      63,   15,   15,   15, 0x0a,
      74,   15,   15,   15, 0x0a,
      98,   91,   15,   15, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_TextEditWidget[] = {
    "TextEditWidget\0\0newText\0setText(QString)\0"
    "setBold()\0setItalic()\0setUnder()\0"
    "insertAndClose()\0format\0"
    "currentCharFormatChanged(QTextCharFormat)\0"
};

void TextEditWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TextEditWidget *_t = static_cast<TextEditWidget *>(_o);
        switch (_id) {
        case 0: _t->setText((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->setBold(); break;
        case 2: _t->setItalic(); break;
        case 3: _t->setUnder(); break;
        case 4: _t->insertAndClose(); break;
        case 5: _t->currentCharFormatChanged((*reinterpret_cast< const QTextCharFormat(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData TextEditWidget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject TextEditWidget::staticMetaObject = {
    { &CmdWidget::staticMetaObject, qt_meta_stringdata_TextEditWidget,
      qt_meta_data_TextEditWidget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TextEditWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TextEditWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TextEditWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TextEditWidget))
        return static_cast<void*>(const_cast< TextEditWidget*>(this));
    return CmdWidget::qt_metacast(_clname);
}

int TextEditWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CmdWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

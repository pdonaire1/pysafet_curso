/****************************************************************************
** Form interface generated from reading ui file 'ui/inflowopciones.ui'
**
** Created: lun oct 19 14:49:50 2009
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/


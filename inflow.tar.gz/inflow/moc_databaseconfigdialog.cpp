/****************************************************************************
** Meta object code from reading C++ file 'databaseconfigdialog.h'
**
** Created: Wed Jul 16 16:14:50 2014
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "databaseconfigdialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'databaseconfigdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_DatabaseConfigDialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      22,   21,   21,   21, 0x0a,
      33,   21,   21,   21, 0x0a,
      50,   44,   21,   21, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_DatabaseConfigDialog[] = {
    "DatabaseConfigDialog\0\0doAccept()\0"
    "doCancel()\0state\0checkBoxLocal(int)\0"
};

void DatabaseConfigDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        DatabaseConfigDialog *_t = static_cast<DatabaseConfigDialog *>(_o);
        switch (_id) {
        case 0: _t->doAccept(); break;
        case 1: _t->doCancel(); break;
        case 2: _t->checkBoxLocal((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData DatabaseConfigDialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject DatabaseConfigDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_DatabaseConfigDialog,
      qt_meta_data_DatabaseConfigDialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &DatabaseConfigDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *DatabaseConfigDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *DatabaseConfigDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DatabaseConfigDialog))
        return static_cast<void*>(const_cast< DatabaseConfigDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int DatabaseConfigDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
